<?php
/*
Plugin Name: WP DEV TOOLS
Plugin URI: http://github.com/hsleonis
Description: Development tools for wordpress coders
Version: 1.0
Author: Md. Hasan Shahriar
Author URI: http://themeaxe.com
License: GPL-v3

Copyright 2016  Md. Hasan Shahriar  (email : hsleonis2@gmail.com)

This program is paid software; you can not redistribute it and/or modify
it under the terms of the GNU General Public License, version 3, as 
published by the Free Software Foundation.
*/

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

require('manager.php');

require('syntaxhighlighter/index.php');

require('database/index.php');
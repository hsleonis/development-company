<?php
/*
Silence is golden!
*/
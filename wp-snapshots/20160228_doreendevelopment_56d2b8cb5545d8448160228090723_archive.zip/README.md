# Developer Website
(c) 2016

# Installation
* Create a directory named 'doreendev'
* Initialize git in that directory:
``
git init
``
* Now clone this repo:
``
git clone https://github.com/hsleonis/development-company.git
``
* You will find the MySQL database in wp-content/database folder, import it. Your database name should be 'doreendev'
* You can change database settings in 'wp-config.php' if needed.
